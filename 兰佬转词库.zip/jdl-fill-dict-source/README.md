1、将个人词库文件放置在当前目录下，词库格式为 *.dict.yaml
2、将需要空码补充的词库内容复制进 All.txt，每行一词，无多余编码
3、完成以上两步后，在当前目录执行 python3 py2jd.py
4、等待一会儿，词库生成为 xkjd6.result.dict.yaml